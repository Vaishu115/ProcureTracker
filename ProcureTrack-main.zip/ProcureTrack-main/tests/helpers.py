"""Helpers shared by the tests. Fixtures are in conftest.py."""

from procuretrack import create_app
from procuretrack.extensions import db
from procuretrack.models import ProcurementRequest, User, Vendor

# The New Request form with one item row. item_* fields repeat once per row.
VALID_REQUEST = {
    "owner": "Vision team",
    "category": "Electronics",
    "procurement_type": "New Purchase",
    "priority": "High",
    "required_by": "2026-10-15",
    "description": "For the inspection rig",
    "item_id": "",
    "item_description": "RTX A1000 GPU",
    "item_quantity": "2",
    "item_unit": "Nos",
}

# shorthand keyword -> form field, for a ticket with one item
ITEM_FIELDS = {"item": "item_description", "quantity": "item_quantity", "unit": "item_unit"}


def request_form(**fields):
    """VALID_REQUEST with changes; item= / quantity= / unit= change the single item row."""
    return {**VALID_REQUEST, **{ITEM_FIELDS.get(k, k): v for k, v in fields.items()}}


def make_app(tmp_path, **overrides):
    """App with its own empty database in tmp_path, test sign-in, CSRF off."""
    config = {
        "TESTING": True,
        "DATA_DIR": tmp_path,
        "LEGACY_DB_PATH": None,
        "OFFSITE_BACKUP_DIR": None,  # ignore any real setting in .env
        "WTF_CSRF_ENABLED": False,
        "SECRET_KEY": "test",
        "AUTH_MODE": "dev",
        "ADMIN_EMAILS": set(),
    }
    config.update(overrides)
    return create_app(config)


def user_id(app, key):
    """Id of a test user created by the `app` fixture, e.g. user_id(app, "approver")."""
    with app.app_context():
        return db.session.scalar(db.select(User.id).where(User.email == f"{key}@eric.test"))


def login(client, app, key):
    """Sign the test client in as a test user (skips the login page)."""
    uid = user_id(app, key)
    with client.session_transaction() as session:
        session.clear()
        session["user_id"] = uid
    return client


def create_via(client, app, data=None, **fields):
    """Create a ticket through the form as `client`; returns its ticket_id."""
    response = client.post("/request", data=data or request_form(**fields))
    assert response.status_code == 302, response.get_data(as_text=True)
    with app.app_context():
        return db.session.scalars(
            db.select(ProcurementRequest.ticket_id).order_by(ProcurementRequest.id.desc())
        ).first()


def edit_form(app, ticket_id, **fields):
    """The Edit form as it would be submitted unchanged, with `fields` changed."""
    ticket = get_ticket(app, ticket_id)
    form = {
        "title": ticket.title or "",
        "project_id": str(ticket.project_id or ""),
        "owner": ticket.owner or "",
        "category": ticket.category,
        "procurement_type": ticket.procurement_type,
        "priority": ticket.priority,
        "required_by": ticket.required_by.isoformat() if ticket.required_by else "",
        "description": ticket.description or "",
        "recommended_vendor_id": str(ticket.recommended_vendor_id or ""),
        "item_id": [str(i.id) for i in ticket.items],
        "item_description": [i.description for i in ticket.items],
        "item_quantity": [str(i.quantity) for i in ticket.items],
        "item_unit": [i.unit for i in ticket.items],
    }
    form.update({ITEM_FIELDS.get(k, k): v for k, v in fields.items()})
    return form


def add_vendor(client, name="Robu", state="29", gstin="", **extra):
    """Add a vendor (Karnataka by default) if it doesn't exist yet; returns its id."""
    client.post(
        "/vendors/new",
        data={
            "name": name,
            "country": "India",
            "state_code": state,
            "gstin": gstin,
            "default_currency": "INR",
            **extra,
        },
    )
    with client.application.app_context():
        return db.session.scalar(db.select(Vendor.id).where(Vendor.name == name))


def set_prices(client, app, ticket_id, price="1000.00", gst="18"):
    """Post the purchase team's prices form with the same price for every item."""
    items = get_ticket(app, ticket_id).items
    data = {}
    for item in items:
        data[f"price-{item.id}"] = price
        data[f"gst-{item.id}"] = gst
    response = client.post(f"/ticket/{ticket_id}/prices", data=data)
    assert response.status_code == 302
    return response


def fill_requisition(client, ticket_id, price="1000.00", gst="18", vendor_name="Robu"):
    """Choose a vendor (added if needed) and price every item: ready for approval."""
    app = client.application
    vendor_id = add_vendor(client, name=vendor_name)
    response = client.post(
        f"/ticket/{ticket_id}/edit",
        data=edit_form(app, ticket_id, recommended_vendor_id=str(vendor_id)),
    )
    assert response.status_code == 302, response.get_data(as_text=True)
    set_prices(client, app, ticket_id, price, gst)
    return vendor_id


def set_stage(app, ticket_id, status):
    """Jump a ticket straight to a stage (test setup only)."""
    with app.app_context():
        ticket = db.session.scalar(
            db.select(ProcurementRequest).where(ProcurementRequest.ticket_id == ticket_id)
        )
        ticket.status = status
        db.session.commit()


def get_ticket(app, ticket_id):
    """Load a ticket, its items and history for assertions (detached from the session)."""
    with app.app_context():
        ticket = db.session.scalar(
            db.select(ProcurementRequest).where(ProcurementRequest.ticket_id == ticket_id)
        )
        if ticket is not None:
            # load related rows before the session closes
            _ = ticket.history, ticket.project, ticket.recommended_vendor, ticket.created_by
            for item in ticket.items:
                _ = item.ticket, [line.po for line in item.po_lines]
            db.session.expunge_all()
        return ticket
