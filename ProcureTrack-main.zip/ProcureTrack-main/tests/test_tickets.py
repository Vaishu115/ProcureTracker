from datetime import date, datetime

from helpers import (
    VALID_REQUEST,
    create_via,
    edit_form,
    get_ticket,
    login,
    make_app,
    request_form,
    set_stage,
)


def test_pages_render(client, create_ticket):
    ticket_id = create_ticket()
    for url in [
        "/",
        "/queue",
        "/request",
        "/tracking",
        "/archive",
        "/reports",
        "/users/",
        f"/ticket/{ticket_id}",
        f"/ticket/{ticket_id}/edit",
    ]:
        assert client.get(url).status_code == 200, url


def test_create_ticket(app, create_ticket):
    year = datetime.now().year
    first = create_ticket()
    second = create_ticket(item="Lidar")
    assert first == f"PROC-{year}-0001"
    assert second == f"PROC-{year}-0002"

    ticket = get_ticket(app, first)
    assert [(i.position, i.description, i.quantity, i.unit) for i in ticket.items] == [
        (1, "RTX A1000 GPU", 2, "Nos")
    ]
    assert ticket.summary == "RTX A1000 GPU"  # no title: the first item's name
    assert ticket.required_by == date(2026, 10, 15)
    assert ticket.status == "Requirement Raised"
    assert ticket.state == "Active"
    assert [h.comment for h in ticket.history] == ["Procurement requirement created"]
    assert ticket.history[0].old_status is None


def test_create_rejects_invalid_input_and_keeps_values(client, app):
    response = client.post(
        "/request",
        data=request_form(item="  ", quantity="abc", category="Nope", required_by="31-02-2026"),
    )
    body = response.get_data(as_text=True)
    assert response.status_code == 400
    assert "Item description is required." in body
    assert "Quantity must be a whole number." in body
    assert "Choose a valid category." in body
    assert "Required by date must be a valid date." in body
    assert "Vision team" in body  # typed values are kept
    assert 'value="abc"' in body  # ... including the item rows
    assert get_ticket(app, f"PROC-{datetime.now().year}-0001") is None


def test_quantity_limits(client):
    for bad in ["0", "-3", "1.5", "99999999"]:
        assert client.post("/request", data=request_form(quantity=bad)).status_code == 400, bad


def test_ticket_needs_at_least_one_item(client):
    response = client.post("/request", data=request_form(item="", quantity=""))
    assert response.status_code == 400
    assert "Add at least one item." in response.get_data(as_text=True)


def test_ticket_with_several_items(client, app):
    ticket_id = create_via(
        client,
        app,
        data={
            **VALID_REQUEST,
            "title": "Drive parts",
            "item_id": ["", "", ""],
            "item_description": ["BLDC Motor", "", "M8 Allen bolt"],  # empty rows are skipped
            "item_quantity": ["10", "", "200"],
            "item_unit": ["Nos", "Nos", "Nos"],
        },
    )
    ticket = get_ticket(app, ticket_id)
    assert [(i.position, i.description, i.quantity) for i in ticket.items] == [
        (1, "BLDC Motor", 10),
        (2, "M8 Allen bolt", 200),
    ]
    assert (ticket.summary, ticket.quantity_summary) == ("Drive parts", "2 items")

    page = client.get("/queue").get_data(as_text=True)
    assert "Drive parts" in page and "2 items" in page


def test_edit_adds_changes_and_removes_items(client, app, create_ticket):
    ticket_id = create_ticket(item="Motor", quantity="10")
    motor_id = get_ticket(app, ticket_id).items[0].id
    client.post(
        f"/ticket/{ticket_id}/edit",
        data={
            **VALID_REQUEST,
            "item_id": ["", str(motor_id)],  # new item first, motor moves to row 2
            "item_description": ["Cable", "Motor"],
            "item_quantity": ["5", "12"],
            "item_unit": ["m", "Nos"],
        },
    )
    ticket = get_ticket(app, ticket_id)
    assert [(i.position, i.description, i.quantity, i.unit) for i in ticket.items] == [
        (1, "Cable", 5, "m"),
        (2, "Motor", 12, "Nos"),
    ]
    assert ticket.items[1].id == motor_id
    assert ticket.history[0].comment == "Item added: Cable, 5 m\nItem Motor: quantity 10 → 12"

    form = edit_form(app, ticket_id)
    form.update(
        item_id=[str(motor_id)], item_description=["Motor"], item_quantity=["12"], item_unit=["Nos"]
    )
    client.post(f"/ticket/{ticket_id}/edit", data=form)
    ticket = get_ticket(app, ticket_id)
    assert [i.description for i in ticket.items] == ["Motor"]
    assert ticket.history[0].comment == "Item removed: Cable"


def test_missing_ticket_returns_404_everywhere(client):
    assert client.get("/ticket/PROC-1999-0001").status_code == 404
    for action in [
        "advance",
        "send-back",
        "hold",
        "resume",
        "cancel",
        "reopen",
        "tracking",
        "archive",
        "restore",
        "delete",
    ]:
        assert (
            client.post(f"/ticket/PROC-1999-0001/{action}", data={"comment": "x"}).status_code
            == 404
        ), action


def test_advance_and_send_back(client, app, create_ticket):
    ticket_id = create_ticket()
    client.post(f"/ticket/{ticket_id}/advance", data={"comment": "Spec agreed"})
    client.post(f"/ticket/{ticket_id}/advance", data={})
    assert get_ticket(app, ticket_id).status == "Vendor Identification"

    # reason is required to send back
    client.post(f"/ticket/{ticket_id}/send-back", data={"comment": ""})
    assert get_ticket(app, ticket_id).status == "Vendor Identification"

    client.post(f"/ticket/{ticket_id}/send-back", data={"comment": "Spec changed"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "Specification Finalized"
    assert ticket.history[0].event_type == "SENT_BACK"
    assert ticket.history[0].comment == "Spec changed"


def test_cannot_send_back_from_first_stage(client, app, create_ticket):
    ticket_id = create_ticket()
    response = client.post(
        f"/ticket/{ticket_id}/send-back", data={"comment": "x"}, follow_redirects=True
    )
    assert "can&#39;t be sent back" in response.get_data(as_text=True)
    assert get_ticket(app, ticket_id).status == "Requirement Raised"


def test_hold_resume_cancel_reopen(client, app, create_ticket):
    ticket_id = create_ticket()

    client.post(f"/ticket/{ticket_id}/hold", data={"comment": "Waiting for budget"})
    assert get_ticket(app, ticket_id).state == "On Hold"

    # can't advance while on hold
    client.post(f"/ticket/{ticket_id}/advance", data={})
    assert get_ticket(app, ticket_id).status == "Requirement Raised"

    client.post(f"/ticket/{ticket_id}/resume", data={})
    assert get_ticket(app, ticket_id).state == "Active"

    client.post(f"/ticket/{ticket_id}/cancel", data={"comment": "Dropped"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.state == "Cancelled"
    assert ticket.status == "Requirement Raised"  # stage is remembered

    client.post(f"/ticket/{ticket_id}/reopen", data={"comment": "Needed again"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.state == "Active"
    assert [h.event_type for h in ticket.history][:4] == [
        "REOPENED",
        "CANCELLED",
        "RESUMED",
        "ON_HOLD",
    ]


def test_closed_ticket_cannot_advance(client, app, create_ticket):
    ticket_id = create_ticket()
    set_stage(app, ticket_id, "Inspection")
    client.post(f"/ticket/{ticket_id}/advance", data={})
    assert get_ticket(app, ticket_id).status == "Closed"
    client.post(f"/ticket/{ticket_id}/advance", data={})
    client.post(f"/ticket/{ticket_id}/cancel", data={"comment": "x"})
    ticket = get_ticket(app, ticket_id)
    assert ticket.status == "Closed" and ticket.state == "Active"


def test_edit_records_changes(client, app, create_ticket):
    ticket_id = create_ticket()
    response = client.post(
        f"/ticket/{ticket_id}/edit",
        data=edit_form(app, ticket_id, quantity=["5"], priority="Critical"),
    )
    assert response.status_code == 302

    ticket = get_ticket(app, ticket_id)
    assert ticket.items[0].quantity == 5
    assert ticket.history[0].event_type == "EDITED"
    assert ticket.history[0].comment == (
        "Priority: High → Critical\nItem RTX A1000 GPU: quantity 2 → 5"
    )

    # invalid edit changes nothing
    response = client.post(
        f"/ticket/{ticket_id}/edit", data=edit_form(app, ticket_id, quantity=["0"])
    )
    assert response.status_code == 400
    assert get_ticket(app, ticket_id).items[0].quantity == 5


def test_tracking_only_after_po_release(client, app, create_ticket):
    ticket_id = create_ticket()
    client.post(
        f"/ticket/{ticket_id}/tracking",
        data={
            "selected_vendor": "Acme",
            "payment_status": "Pending",
            "fulfilment_status": "Not Ordered",
        },
    )
    assert get_ticket(app, ticket_id).selected_vendor is None

    set_stage(app, ticket_id, "PO Released")

    bad = client.post(
        f"/ticket/{ticket_id}/tracking",
        data={
            "payment_status": "Pending",
            "fulfilment_status": "Not Ordered",
            "expected_delivery": "soon",
        },
    )
    assert bad.status_code == 400

    client.post(
        f"/ticket/{ticket_id}/tracking",
        data={
            "selected_vendor": "Acme Components",
            "po_number": "PO-778",
            "payment_status": "Partial",
            "fulfilment_status": "Order Confirmed",
            "expected_delivery": "2026-10-01",
            "tracking_comment": "Advance paid",
        },
    )
    ticket = get_ticket(app, ticket_id)
    assert ticket.expected_delivery == date(2026, 10, 1)
    assert ticket.history[0].event_type == "TRACKING_UPDATE"
    assert ticket.history[0].comment.startswith("Advance paid\nVendor: — → Acme Components")


def test_archive_restore_delete(client, app, create_ticket):
    ticket_id = create_ticket()
    client.post(f"/ticket/{ticket_id}/archive")
    assert get_ticket(app, ticket_id).archived is True
    link = f'href="/ticket/{ticket_id}"'
    assert link not in client.get("/queue").get_data(as_text=True)
    assert link in client.get("/archive").get_data(as_text=True)

    client.post(f"/ticket/{ticket_id}/restore")
    assert get_ticket(app, ticket_id).archived is False

    client.post(f"/ticket/{ticket_id}/delete")
    assert get_ticket(app, ticket_id) is None
    with app.app_context():
        from procuretrack.extensions import db
        from procuretrack.models import StatusHistory

        assert db.session.scalar(db.select(db.func.count()).select_from(StatusHistory)) == 0


def test_overdue_flag(client, app, create_ticket):
    ticket_id = create_ticket(required_by="2020-01-01")
    assert get_ticket(app, ticket_id).is_overdue
    assert "Overdue" in client.get("/queue").get_data(as_text=True)


def test_csrf_blocks_forms_without_token(tmp_path):
    from procuretrack.extensions import db
    from procuretrack.models import User

    app = make_app(tmp_path, WTF_CSRF_ENABLED=True)
    with app.app_context():
        db.session.add(User(email="requester@eric.test", name="Rahul"))
        db.session.commit()
    client = login(app.test_client(), app, "requester")
    response = client.post("/request", data=request_form())
    assert response.status_code == 400
    assert "Form expired" in response.get_data(as_text=True)


def test_timeline_scrolls_when_long(client, create_ticket):
    ticket_id = create_ticket()
    assert "timeline-scroll" not in client.get(f"/ticket/{ticket_id}").get_data(as_text=True)
    for _ in range(2):
        client.post(f"/ticket/{ticket_id}/hold", data={"comment": "x"})
        client.post(f"/ticket/{ticket_id}/resume", data={})
    assert "timeline-scroll" in client.get(f"/ticket/{ticket_id}").get_data(as_text=True)


def test_categories_and_old_category_kept_on_edit(client, app, create_ticket):
    page = client.get("/request").get_data(as_text=True)
    for category in ["Electronics", "Mechanical", "Software", "Service"]:
        assert f'value="{category}"' in page
    assert 'value="Sensor"' not in page
    assert client.post("/request", data=request_form(category="Sensor")).status_code == 400

    # a ticket from before still has its old category and can be edited
    ticket_id = create_ticket()
    with app.app_context():
        from procuretrack.extensions import db
        from procuretrack.models import ProcurementRequest

        ticket = db.session.scalar(
            db.select(ProcurementRequest).where(ProcurementRequest.ticket_id == ticket_id)
        )
        ticket.category = "Consumables"
        db.session.commit()
    assert 'value="Consumables" selected' in client.get(f"/ticket/{ticket_id}/edit").get_data(
        as_text=True
    )
    form = edit_form(app, ticket_id, priority="Low")
    assert client.post(f"/ticket/{ticket_id}/edit", data=form).status_code == 302
    assert get_ticket(app, ticket_id).category == "Consumables"
