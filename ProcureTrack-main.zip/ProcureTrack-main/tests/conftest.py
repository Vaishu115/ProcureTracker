"""
pytest fixtures. Each test gets a fresh app and database in a temp folder,
with one test user per role (see TEST_USERS).
"""

import pytest

from procuretrack.extensions import db
from procuretrack.models import User

from helpers import create_via, login, make_app

# key -> (name, role, is_admin). Emails are <key>@eric.test.
TEST_USERS = {
    "admin": ("Sagar", "purchase", True),
    "purchase": ("Priya", "purchase", False),
    "approver": ("Chirag", "approver", False),
    "requester": ("Rahul", "requester", False),
    "requester2": ("Anita", "requester", False),
}


@pytest.fixture
def app(tmp_path):
    app = make_app(tmp_path)
    with app.app_context():
        for key, (name, role, is_admin) in TEST_USERS.items():
            db.session.add(User(email=f"{key}@eric.test", name=name, role=role, is_admin=is_admin))
        db.session.commit()
    return app


@pytest.fixture
def client_as(app):
    """client_as("approver") -> test client signed in as that test user."""

    def _client(key):
        return login(app.test_client(), app, key)

    return _client


@pytest.fixture
def client(client_as):
    """Default client: purchase team + admin."""
    return client_as("admin")


@pytest.fixture
def create_ticket(client, app):
    """Create a ticket through the form (as the default client) and return its ticket_id."""

    def _create(**fields):
        return create_via(client, app, **fields)

    return _create
