"""Vendors, projects, company settings and purchase orders."""

from datetime import date
from decimal import Decimal

import pytest

from procuretrack.extensions import db
from procuretrack.models import CompanySettings, PurchaseOrder, Vendor
from procuretrack.money import amount_in_words, format_amount, line_amounts
from procuretrack.purchasing import financial_year

from helpers import create_via, edit_form, get_ticket, request_form, set_prices, set_stage

# ---- money (pure functions) ----


def test_gst_split_by_tax_type():
    intra = line_amounts(3, Decimal("1000.00"), Decimal("18"), "intra")
    assert (intra.taxable, intra.cgst, intra.sgst, intra.igst) == (
        Decimal("3000.00"),
        Decimal("270.00"),
        Decimal("270.00"),
        Decimal("0"),
    )
    assert intra.total == Decimal("3540.00")

    inter = line_amounts(3, Decimal("1000.00"), Decimal("18"), "inter")
    assert (inter.igst, inter.total) == (Decimal("540.00"), Decimal("3540.00"))

    imported = line_amounts(3, Decimal("1000.00"), Decimal("18"), "import")
    assert imported.total == Decimal("3000.00")


def test_rounding_is_half_up_per_line():
    amounts = line_amounts(1, Decimal("0.05"), Decimal("5"), "inter")  # 0.0025 -> 0.00
    assert amounts.igst == Decimal("0.00")
    amounts = line_amounts(1, Decimal("0.10"), Decimal("5"), "inter")  # 0.005 -> 0.01
    assert amounts.igst == Decimal("0.01")


def test_formatting():
    assert format_amount(Decimal("12345678.5")) == "₹1,23,45,678.50"
    assert format_amount(Decimal("999")) == "₹999.00"
    assert format_amount(Decimal("1234567.891"), "USD") == "$1,234,567.89"
    assert (
        amount_in_words(Decimal("120000.50"))
        == "Rupees One Lakh Twenty Thousand and Fifty Paise Only"
    )
    assert amount_in_words(Decimal("21500000")) == "Rupees Two Crore Fifteen Lakh Only"
    assert amount_in_words(Decimal("1250.75"), "USD") == (
        "US Dollars One Thousand Two Hundred Fifty and Seventy Five Cents Only"
    )


def test_financial_year():
    assert financial_year(date(2026, 9, 24)) == "2026-27"
    assert financial_year(date(2027, 3, 31)) == "2026-27"
    assert financial_year(date(2027, 4, 1)) == "2027-28"


# ---- setup helpers ----

KARNATAKA_GSTIN = "29ABCDE1234F1Z5"
MAHARASHTRA_GSTIN = "27ABCDE1234F1Z5"


def save_company(client):
    response = client.post(
        "/settings/",
        data={
            "name": "ERIC Robotics Pvt Ltd",
            "address": "Bengaluru",
            "state_code": "29",
            "gstin": KARNATAKA_GSTIN,
            "po_prefix": "ERIC/PO",
            "default_terms": "Delivery within 2 weeks.",
        },
    )
    assert response.status_code == 302, response.get_data(as_text=True)


def add_vendor(client, name="Robu", state="29", gstin=KARNATAKA_GSTIN, **extra):
    data = {"name": name, "country": "India", "state_code": state, "gstin": gstin}
    data.setdefault("default_currency", "INR")
    data.update(extra)
    response = client.post("/vendors/new", data=data)
    assert response.status_code == 302, response.get_data(as_text=True)
    return int(response.headers["Location"].rsplit("/", 1)[1])


def approved_ticket(client, app, quantity="10", **fields):
    ticket_id = create_via(client, app, quantity=quantity, **fields)
    set_stage(app, ticket_id, "PO Released")
    return ticket_id


def new_draft(client, vendor_id):
    response = client.post("/pos/new", data={"vendor_id": vendor_id})
    assert response.status_code == 302
    return int(response.headers["Location"].split("/pos/")[1].split("?")[0])


def add_line(client, po_id, item_id, quantity, price="1000.00", gst="18"):
    return client.post(
        f"/pos/{po_id}/lines",
        data={"item_id": item_id, "quantity": quantity, "unit_price": price, "gst_rate": gst},
    )


def item_pk(app, ticket_id):
    return get_ticket(app, ticket_id).id


def po(app, po_id):
    with app.app_context():
        order = db.session.get(PurchaseOrder, po_id)
        _ = order.vendor, [(line.item.ticket, line.po) for line in order.lines]
        db.session.expunge_all()
        return order


# ---- vendors, projects, settings ----


def test_vendor_gstin_validation(client):
    bad_format = client.post(
        "/vendors/new", data={"name": "X", "country": "India", "state_code": "29", "gstin": "123"}
    )
    assert "GSTIN must be 15 characters" in bad_format.get_data(as_text=True)

    wrong_state = client.post(
        "/vendors/new",
        data={"name": "X", "country": "India", "state_code": "29", "gstin": MAHARASHTRA_GSTIN},
    )
    assert "registered in Maharashtra" in wrong_state.get_data(as_text=True)

    no_state = client.post("/vendors/new", data={"name": "X", "country": "India"})
    assert "State is required." in no_state.get_data(as_text=True)

    # foreign vendors need no state or GSTIN
    add_vendor(
        client, name="Digi-Key", state="", gstin="", country="United States", default_currency="USD"
    )


def test_pan_must_match_gstin_and_is_filled_from_it(app, client):
    wrong = client.post(
        "/vendors/new",
        data={
            "name": "X",
            "country": "India",
            "state_code": "29",
            "gstin": KARNATAKA_GSTIN,
            "pan": "ZZZZZ9999Z",
        },
    )
    assert "PAN doesn&#39;t match the GSTIN, which contains the PAN ABCDE1234F." in wrong.get_data(
        as_text=True
    )

    vendor_id = add_vendor(client)  # GSTIN given, PAN left empty
    with app.app_context():
        assert db.session.get(Vendor, vendor_id).pan == "ABCDE1234F"

    save_company(client)
    with app.app_context():
        assert CompanySettings.get().pan == "ABCDE1234F"


def test_vendor_names_are_unique(client):
    add_vendor(client)
    duplicate = client.post(
        "/vendors/new", data={"name": "ROBU", "country": "India", "state_code": "29"}
    )
    assert "already exists" in duplicate.get_data(as_text=True)


def test_projects_are_managed_by_purchase_team(app, client, client_as):
    assert client.post("/projects/", data={"name": "RailwayMitra"}).status_code == 302
    assert client.post("/projects/", data={"name": "railwaymitra"}).status_code == 400
    assert client_as("requester").post("/projects/", data={"name": "X"}).status_code == 403
    assert client_as("requester").get("/projects/").status_code == 200

    ticket_id = create_via(client_as("requester"), app, project_id="1")
    assert get_ticket(app, ticket_id).project_id == 1


def test_settings_are_admin_only(client, client_as):
    assert client_as("purchase").get("/settings/").status_code == 403
    save_company(client)
    assert client.get("/settings/").status_code == 200


# ---- purchase orders ----


def test_full_po_flow(app, client, client_as):
    save_company(client)
    vendor_id = add_vendor(client)  # same state as ERIC -> CGST + SGST
    ticket_id = approved_ticket(client, app, quantity="10")
    pk = item_pk(app, ticket_id)

    po_id = new_draft(client, vendor_id)
    assert po(app, po_id).tax_type == "intra"

    # can't order more than the ticket needs
    too_many = add_line(client, po_id, pk, "11")
    assert too_many.status_code == 302
    assert po(app, po_id).lines == []

    add_line(client, po_id, pk, "6", price="1,000.50")
    draft = po(app, po_id)
    assert len(draft.lines) == 1
    assert draft.lines[0].unit_price == Decimal("1000.50")
    assert get_ticket(app, ticket_id).items[0].remaining_quantity == 4

    # requesters can look but not touch
    assert client_as("requester").get(f"/pos/{po_id}").status_code == 200
    assert client_as("requester").post(f"/pos/{po_id}/issue").status_code == 403

    page = client.get(f"/pos/{po_id}").get_data(as_text=True)
    assert "₹7,083.54" in page  # 6 x 1000.50 = 6003.00 + 18% GST 1080.54

    response = client.post(f"/pos/{po_id}/issue", follow_redirects=True)
    assert "issued" in response.get_data(as_text=True)
    issued = po(app, po_id)
    assert issued.status == "Issued"
    assert issued.po_number == f"ERIC/PO/{financial_year(date.today())}/0001"
    assert issued.vendor_snapshot["gstin"] == KARNATAKA_GSTIN

    ticket = get_ticket(app, ticket_id)
    assert ticket.items[0].ordered_quantity == 6
    event = ticket.history[0]
    assert event.event_type == "PO_ISSUED"
    assert event.comment == (
        f"PO {issued.po_number} to Robu\nRTX A1000 GPU: 6 Nos at ₹1,000.50 + GST 18%"
    )

    # locked after issue
    line_id = issued.lines[0].id
    client.post(
        f"/pos/{po_id}/lines/{line_id}",
        data={"quantity": "1", "unit_price": "1", "gst_rate": "0"},
    )
    assert po(app, po_id).lines[0].quantity == 6

    # the printable PO
    printed = client.get(f"/pos/{po_id}/print").get_data(as_text=True)
    assert issued.po_number in printed
    assert "Rupees Seven Thousand Eighty Three and Fifty Four Paise Only" in printed
    assert "CGST" in printed and "IGST" not in printed

    # editing the vendor later doesn't change the issued PO
    client.post(
        f"/vendors/{vendor_id}/edit",
        data={
            "name": "Robu Renamed",
            "country": "India",
            "state_code": "29",
            "default_currency": "INR",
        },
    )
    assert "Robu Renamed" not in client.get(f"/pos/{po_id}/print").get_data(as_text=True)

    # cancelling returns the quantity to the ticket
    client.post(f"/pos/{po_id}/cancel", data={"comment": "Vendor out of stock"})
    assert po(app, po_id).status == "Cancelled"
    item = get_ticket(app, ticket_id).items[0]
    assert (item.ordered_quantity, item.remaining_quantity) == (0, 10)
    ticket = get_ticket(app, ticket_id)
    assert ticket.history[0].event_type == "PO_CANCELLED"


def test_split_ticket_across_vendors_and_combine_tickets(app, client):
    save_company(client)
    robu = add_vendor(client)
    other = add_vendor(client, name="Mumbai Motors", state="27", gstin=MAHARASHTRA_GSTIN)
    gpu = approved_ticket(client, app, quantity="10", item="GPU")
    cable = approved_ticket(client, app, quantity="5", item="Cable", unit="m")

    first = new_draft(client, robu)
    add_line(client, first, item_pk(app, gpu), "6")
    add_line(client, first, item_pk(app, cable), "5")  # two tickets on one PO
    assert len(po(app, first).lines) == 2

    second = new_draft(client, other)  # other state -> IGST
    assert po(app, second).tax_type == "inter"
    add_line(client, second, item_pk(app, gpu), "5")  # only 4 left
    assert po(app, second).lines == []
    add_line(client, second, item_pk(app, gpu), "4")

    for po_id in (first, second):
        client.post(f"/pos/{po_id}/issue")
    numbers = {po(app, first).po_number, po(app, second).po_number}
    assert len(numbers) == 2

    assert get_ticket(app, gpu).items[0].ordered_quantity == 10
    assert get_ticket(app, gpu).can_be_ordered is False
    assert "IGST" in client.get(f"/pos/{second}/print").get_data(as_text=True)


def test_only_approved_open_tickets_can_be_ordered(app, client):
    save_company(client)
    vendor_id = add_vendor(client)
    not_approved = create_via(client, app)  # still at Requirement Raised
    po_id = new_draft(client, vendor_id)
    add_line(client, po_id, item_pk(app, not_approved), "1")
    assert po(app, po_id).lines == []


def test_issue_needs_company_details_and_lines(app, client):
    vendor_id = add_vendor(client)
    po_id = new_draft(client, vendor_id)

    response = client.post(f"/pos/{po_id}/issue", follow_redirects=True)
    assert "Fill in the company details" in response.get_data(as_text=True)

    save_company(client)
    response = client.post(f"/pos/{po_id}/issue", follow_redirects=True)
    assert "Add at least one line" in response.get_data(as_text=True)
    assert po(app, po_id).status == "Draft"


def test_foreign_currency_import_po(app, client):
    save_company(client)
    vendor_id = add_vendor(
        client, name="Digi-Key", state="", gstin="", country="United States", default_currency="USD"
    )
    ticket_id = approved_ticket(client, app, quantity="2")
    po_id = new_draft(client, vendor_id)
    assert (po(app, po_id).currency, po(app, po_id).tax_type) == ("USD", "import")

    client.post(
        f"/pos/{po_id}/header",
        data={"vendor_id": vendor_id, "currency": "USD", "exchange_rate": "83.25"},
    )
    add_line(client, po_id, item_pk(app, ticket_id), "2", price="150.00", gst="0")
    order = po(app, po_id)
    with app.app_context():
        order = db.session.get(PurchaseOrder, po_id)
        assert order.totals.total == Decimal("300.00")
        assert order.total_inr == Decimal("24975.00")

    page = client.get(f"/pos/{po_id}").get_data(as_text=True)
    assert "$300.00" in page and "₹24,975.00" in page


def test_foreign_currency_needs_exchange_rate(app, client):
    vendor_id = add_vendor(client)
    po_id = new_draft(client, vendor_id)
    response = client.post(
        f"/pos/{po_id}/header",
        data={"vendor_id": vendor_id, "currency": "USD", "exchange_rate": ""},
        follow_redirects=True,
    )
    assert "Exchange rate must be a number" in response.get_data(as_text=True)
    assert po(app, po_id).currency == "INR"


def test_item_on_a_po_cannot_shrink_or_be_removed(app, client):
    save_company(client)
    vendor_id = add_vendor(client)
    ticket_id = approved_ticket(client, app, quantity="10")
    po_id = new_draft(client, vendor_id)
    add_line(client, po_id, item_pk(app, ticket_id), "8")

    # sent back for re-approval, so the items can be edited again
    set_stage(app, ticket_id, "Approval Pending")
    response = client.post(
        f"/ticket/{ticket_id}/edit", data=edit_form(app, ticket_id, quantity=["5"])
    )
    assert response.status_code == 400
    assert "1. RTX A1000 GPU: 8 Nos are already on POs." in response.get_data(as_text=True)

    removed = edit_form(app, ticket_id, item_id="", item_description="Other", quantity="1")
    response = client.post(f"/ticket/{ticket_id}/edit", data=removed)
    assert "is on a PO, so it can&#39;t be removed" in response.get_data(as_text=True)
    assert [i.description for i in get_ticket(app, ticket_id).items] == ["RTX A1000 GPU"]


def test_add_all_items_of_a_ticket(app, client):
    save_company(client)
    vendor_id = add_vendor(client)
    ticket_id = create_via(
        client,
        app,
        data=request_form(
            item_id=["", ""],
            item_description=["Motor", "Driver"],
            item_quantity=["4", "2"],
            item_unit=["Nos", "Nos"],
        ),
    )
    pk = get_ticket(app, ticket_id).id

    # not priced yet
    set_stage(app, ticket_id, "PO Released")
    po_id = new_draft(client, vendor_id)
    response = client.post(
        f"/pos/{po_id}/add-ticket", data={"ticket_id": pk}, follow_redirects=True
    )
    assert "No estimated price for 1. Motor, 2. Driver" in response.get_data(as_text=True)

    set_stage(app, ticket_id, "Vendor Selected")
    set_prices(client, app, ticket_id, price="250.00", gst="18")
    set_stage(app, ticket_id, "PO Released")

    # one item partly ordered already: only the rest is added
    first_item = get_ticket(app, ticket_id).items[0].id
    other_po = new_draft(client, vendor_id)
    add_line(client, other_po, first_item, "3")

    client.post(f"/pos/{po_id}/add-ticket", data={"ticket_id": pk})
    lines = po(app, po_id).lines
    assert [(line.description, line.quantity, line.unit_price) for line in lines] == [
        ("Motor", 1, Decimal("250.00")),
        ("Driver", 2, Decimal("250.00")),
    ]
    assert not get_ticket(app, ticket_id).can_be_ordered

    # foreign-currency POs: estimates are in rupees, so items are added one by one
    usd = add_vendor(
        client, name="Digi-Key", state="", gstin="", country="United States", default_currency="USD"
    )
    usd_po = new_draft(client, usd)
    response = client.post(
        f"/pos/{usd_po}/add-ticket", data={"ticket_id": pk}, follow_redirects=True
    )
    assert "add the items one by one" in response.get_data(as_text=True)


def test_draft_can_be_deleted_but_issued_cannot(app, client):
    save_company(client)
    vendor_id = add_vendor(client)
    ticket_id = approved_ticket(client, app)
    draft = new_draft(client, vendor_id)
    client.post(f"/pos/{draft}/delete")
    with app.app_context():
        assert db.session.get(PurchaseOrder, draft) is None

    issued = new_draft(client, vendor_id)
    add_line(client, issued, item_pk(app, ticket_id), "1")
    client.post(f"/pos/{issued}/issue")
    client.post(f"/pos/{issued}/delete")
    assert po(app, issued).status == "Issued"


@pytest.mark.parametrize("page", ["/pos/", "/pos/new", "/vendors/", "/vendors/new", "/projects/"])
def test_purchasing_pages_render(client, page):
    add_vendor(client)
    assert client.get(page).status_code == 200


def test_company_settings_defaults(app):
    with app.app_context():
        settings = CompanySettings.get()
        assert (settings.name, settings.is_complete) == ("ERIC Robotics", False)
        assert Vendor(name="X").country == "India"
