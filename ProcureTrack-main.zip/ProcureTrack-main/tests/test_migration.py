"""Upgrading a database created by V0.3 (raw SQL, text dates)."""

import sqlite3
from datetime import date, datetime

from helpers import get_ticket, login, make_app

# Exactly what V0.3's init_db() created.
V03_SCHEMA = """
CREATE TABLE procurement_requests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT UNIQUE,
    item TEXT NOT NULL,
    project TEXT,
    owner TEXT,
    category TEXT,
    procurement_type TEXT,
    quantity INTEGER DEFAULT 1,
    priority TEXT DEFAULT 'Normal',
    description TEXT,
    request_date TEXT,
    required_by TEXT,
    status TEXT,
    selected_vendor TEXT,
    po_number TEXT,
    payment_status TEXT DEFAULT 'Pending',
    fulfilment_status TEXT DEFAULT 'Not Ordered',
    expected_delivery TEXT,
    archived INTEGER DEFAULT 0
);
CREATE TABLE status_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id TEXT,
    timestamp TEXT,
    event_type TEXT,
    old_status TEXT,
    new_status TEXT,
    comment TEXT
);
"""


def build_v03_database(path):
    conn = sqlite3.connect(path)
    conn.executescript(V03_SCHEMA)
    conn.execute(
        "INSERT INTO procurement_requests(ticket_id,item,project,owner,category,procurement_type,quantity,priority,"
        "description,request_date,required_by,status,payment_status,fulfilment_status,expected_delivery,archived) "
        "VALUES('PROC-2026-0001','GPU','RailwayMitra','Sagar','Compute','New Purchase',1,'Normal','',"
        "'30-08-2026 16:39:01','2026-08-31','Closed','Completed','Delivered','2026-09-05',0)"
    )
    conn.execute(
        "INSERT INTO procurement_requests(ticket_id,item,request_date,required_by,status,expected_delivery,archived) "
        "VALUES('PROC-2026-0002','Motor','31-08-2026 10:33:41','','PO Released','next week',1)"
    )
    conn.execute(
        "INSERT INTO status_history(ticket_id,timestamp,event_type,old_status,new_status,comment) "
        "VALUES('PROC-2026-0001','30-08-2026 16:39:01','STATUS_CHANGE',NULL,'Requirement Raised','Procurement requirement created')"
    )
    conn.commit()
    conn.close()


def test_v03_database_is_upgraded(tmp_path):
    data_dir = tmp_path / "data"
    legacy = tmp_path / "procurement.db"
    build_v03_database(legacy)

    app = make_app(data_dir, LEGACY_DB_PATH=legacy)

    # copied into the data folder; the original file is untouched
    assert (data_dir / "procurement.db").exists()
    assert legacy.exists()
    # a backup was taken before the schema changed
    assert list((data_dir / "backups").glob("procurement-*-pre-migration.db"))

    first = get_ticket(app, "PROC-2026-0001")
    assert first.request_date == datetime(2026, 8, 30, 16, 39, 1)
    assert first.required_by == date(2026, 8, 31)
    assert first.expected_delivery == date(2026, 9, 5)
    assert first.state == "Active"
    assert first.archived is False
    assert first.history[0].timestamp == datetime(2026, 8, 30, 16, 39, 1)

    second = get_ticket(app, "PROC-2026-0002")
    assert second.required_by is None
    assert second.expected_delivery is None
    assert second.archived is True
    # each old ticket became one item (V0.6.2)
    assert [(i.description, i.quantity, i.unit) for i in second.items] == [("Motor", 1, "Nos")]
    assert second.title is None and second.summary == "Motor"
    note = second.history[0]
    assert note.event_type == "MIGRATION_NOTE"
    assert "'next week'" in note.comment

    # free-text project names became managed projects (V0.6)
    assert first.project_name == "RailwayMitra"
    assert first.items[0].unit == "Nos"
    assert second.project_id is None

    # tickets from before sign-in existed have no user attached
    assert first.created_by_id is None
    assert first.history[0].actor_name is None

    # the upgraded database accepts users and new tickets
    from procuretrack.extensions import db
    from procuretrack.models import User

    with app.app_context():
        db.session.add(User(email="requester@eric.test", name="Rahul"))
        db.session.commit()
    client = login(app.test_client(), app, "requester")
    response = client.post(
        "/request",
        data={
            "category": "Mechanical",
            "procurement_type": "Other",
            "priority": "Low",
            "item_description": "Cable",
            "item_quantity": "1",
            "item_unit": "m",
        },
    )
    assert response.status_code == 302
    with app.app_context():
        # ids continue after the copied rows (AUTOINCREMENT kept through the rebuilds)
        from procuretrack.models import ProcurementRequest

        newest = db.session.scalars(
            db.select(ProcurementRequest).order_by(ProcurementRequest.id.desc())
        ).first()
        assert newest.id == 3
        assert newest.created_by.name == "Rahul"


def test_restart_does_not_migrate_or_backup_again(tmp_path):
    legacy = tmp_path / "procurement.db"
    build_v03_database(legacy)
    make_app(tmp_path / "data", LEGACY_DB_PATH=legacy)
    make_app(tmp_path / "data", LEGACY_DB_PATH=legacy)
    assert len(list((tmp_path / "data" / "backups").glob("*.db"))) == 1


def test_fresh_install_creates_schema(tmp_path):
    app = make_app(tmp_path)
    client = app.test_client()
    assert client.get("/login").status_code == 200
    assert client.get("/").status_code == 302  # sign-in required
    assert not (tmp_path / "backups").exists()
