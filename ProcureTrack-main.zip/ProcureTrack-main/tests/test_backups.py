"""Backups: local rotation and the optional off-site copy."""

import sqlite3

from procuretrack.database import backup_database

from helpers import make_app


def test_backup_is_a_readable_copy_and_old_ones_are_pruned(tmp_path):
    app = make_app(tmp_path, BACKUP_KEEP=2)
    paths = [backup_database(app, f"test{i}") for i in range(3)]

    remaining = sorted((tmp_path / "backups").glob("*.db"))
    assert len(remaining) == 2
    assert not paths[0].exists()

    with sqlite3.connect(paths[-1]) as conn:
        tables = {
            row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
    assert {"procurement_requests", "status_history", "users"} <= tables


def test_backup_is_also_copied_offsite(tmp_path):
    offsite = tmp_path / "onedrive" / "ProcureTrack"
    app = make_app(tmp_path / "data", OFFSITE_BACKUP_DIR=offsite)
    path = backup_database(app)
    assert (offsite / path.name).exists()


def test_unreachable_offsite_folder_does_not_break_local_backup(tmp_path):
    blocker = tmp_path / "not-a-folder"
    blocker.write_text("a file where the folder should be")
    app = make_app(tmp_path / "data", OFFSITE_BACKUP_DIR=blocker / "sub")
    path = backup_database(app)
    assert path.exists()
