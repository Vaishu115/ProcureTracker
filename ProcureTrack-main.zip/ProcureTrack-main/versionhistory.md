# ProcureTrack Version History


## V0.3.0

Date:
29-Aug-2026

Features:
- Flask backend
- SQLite database
- Multi-page architecture
- Dashboard
- Queue
- Ticket detail
- Archive
- Restore
- Delete


## V0.3.1

Date:
30-Aug-2026 

Changes:
- New Request form upgrade
- Category field
- Priority field
- Quantity field
- Procurement type


## V0.4.0

Date:
24-Sep-2026

Restructure and hardening. Existing data is upgraded automatically on first start.

Changes:
- Code split into the procuretrack/ package (models, views, services, validation)
- SQLAlchemy + Alembic migrations; database schema upgrades itself on startup,
  after taking an automatic backup
- Database moved out of the code folder into a data folder (instance/ by default,
  or PROCURETRACK_DATA_DIR)
- Dates stored as real dates (were text in mixed formats)
- Edit tickets after creation; every change is recorded in the timeline
- Workflow: send back to previous stage, put on hold / resume, cancel / reopen
  (reason required, stage remembered)
- Validation with messages next to each field; typed values are kept on error
- Overdue flag and On Hold / Overdue counts on the dashboard
- Archive and restore are now recorded in the timeline
- Friendly 404 / error pages
- CSRF protection on all forms; secret key generated per installation
- Production server (waitress) instead of Flask debug mode
- Icons served locally (work offline, version pinned)
- `flask --app app backup` command with 30-backup rotation
- Phone layout with menu button (sidebar was hidden on small screens)
- Pinned requirements, .gitignore, automated tests

Fixes (V0.4.0):
- Crash when advancing a ticket that doesn't exist
- Crash on non-numeric quantity; zero / negative quantities accepted
- Archive / delete button styles only applied on small screens


## V0.5.0

Date:
24-Sep-2026

Sign-in, roles and approval control.

Changes:
- Sign-in required for every page
- Microsoft 365 sign-in (Entra ID); switches on when the PROCURETRACK_MS_* settings are set.
  Until then, a test "sign in as" page that only works on the server itself
- Roles: Requester, Purchase team, Approver, plus an Admin flag
- Only Approvers can approve or reject at Approval Pending; nobody approves their own ticket
- Approve / Reject panel on the ticket; "Waiting for Your Approval" list on the approver's dashboard
- "Send for Approval" button for the purchase team at Vendor Selected
- Requesters can edit or cancel their own ticket until it is sent for approval
- Timeline shows who did each action; tickets record who raised them
- Users page for admins: add people, change roles, disable access
- `flask --app app add-user` command to create the first admin
- Buttons only appear for people allowed to use them; the server also enforces it


## V0.5.1

Date:
24-Sep-2026

Changes:
- Approvers can approve tickets they raised themselves; the timeline marks these "Self-approved"
  (switch off with ALLOW_SELF_APPROVAL in config.py)
- Handover documentation: docs/DEVELOPER_GUIDE.md (architecture, workflow, permissions,
  conventions, how-to recipes) and docs/ROADMAP.md
- Code formatted and linted with ruff (settings in pyproject.toml)
- Development tools moved to requirements-dev.txt; test helpers moved to tests/helpers.py


## V0.5.2

Date:
24-Sep-2026

Changes:
- Data moved out of the code folder to C:\ProcureTrack\data
- Settings can be kept in a .env file (template: .env.example), read by every way of starting the app
- Optional off-site copy of every backup (PROCURETRACK_OFFSITE_BACKUP_DIR)
- Daily backup scheduled in Windows Task Scheduler ("ProcureTrack Backup", 18:00, catches up if the PC was off)
- Clear log warning when the app creates a new empty database (wrong data folder)


## V0.6.0

Date:
24-Sep-2026

Purchasing: vendors, projects and purchase orders.

Changes:
- Vendors: directory with search, GSTIN and PAN validation (GSTIN must match the state),
  Indian or foreign, payment terms, default currency, active/inactive, PO history and total spend
- Projects: managed list replacing the free-text project field (existing names converted)
- Unit of measure on tickets (Nos, m, kg, ...)
- Company settings (admin): name, address, state, GSTIN, delivery address, PO prefix, default terms
- Purchase orders:
  - Draft -> Issued -> (Cancelled); numbered per financial year, e.g. ERIC/PO/2026-27/0001
  - Lines come from approved tickets; a PO can combine tickets and a ticket can be split across POs
  - Quantities can never exceed what the ticket needs; cancelling gives the quantity back
  - Full GST: CGST + SGST or IGST chosen from the vendor's state; imports without GST
  - Foreign currency with exchange rate and INR total
  - Issued POs are locked; vendor and company details are frozen at issue
  - Printable A4 PO with GST split and amount in words (Print / Save as PDF)
- Ticket page shows its POs and quantity ordered / still to order; issuing and cancelling POs
  are recorded on each ticket's timeline
- Sidebar: Purchase Orders, Vendors, Projects, Settings


## V0.6.1

Date:
24-Sep-2026

Matches ERIC's Purchase Requisition Form.

Changes:
- Requisition on each ticket: recommended vendor, estimated unit price and GST %, filled in by
  the purchase team; required before "Send for Approval"; locked once approved
- The approver sees the vendor and estimated cost (incl. GST) when approving
- Printable Purchase Requisition Form in ERIC's format, with last purchase date / rate from
  earlier POs and digital requisitioner and Director signatures
- Printed PO redesigned in the same format (navy logo, info table, 7-column items table,
  GST rows, signature boxes); dates printed as 25-08-2026
- New PO from a ticket pre-selects the recommended vendor; adding the ticket pre-fills the
  approved price and GST
- User department and company plant (printed on the forms)

Fixes:
- Printed PO used the white sidebar logo, which is invisible on paper


## V0.6.2

Date:
28-Sep-2026

Matches how ERIC buys: engineers choose the vendor and items, purchase adds the prices.
Existing data is upgraded automatically (each old ticket becomes one item).

Changes:
- A ticket is a full requisition: one recommended vendor and several items (Sr. No.,
  description, quantity, unit), like ERIC's Purchase Requisition Form. Title is optional;
  lists show the first item and how many more
- Engineers choose the vendor and add / change / remove items when raising or editing
  their ticket (until it is sent for approval). A vendor not in the list can be added
  from the request form itself ("+ Add a new vendor")
- Purchase team enters the estimated price and GST % per item on the ticket page, and can
  change the vendor or items until approval; every change is in the timeline
- "Send for Approval" needs the vendor and a price for every item; after approval the
  vendor, items and prices are locked
- Printed requisition lists every item; the engineer who raised it signs as Requisitioner
- POs: lines are per item. "Add all items of a ticket" adds everything still to order at the
  approved prices; items can still be split across vendors and combined on one PO
- Ticket page shows per item what is on issued POs and what is still to order
- Activity timeline scrolls inside its box once it has more than 3 entries
- PAN must match the GSTIN (vendors and company settings); left empty, it is filled in
  from the GSTIN
- Sign-in page uses the navy ERIC logo
- "Send for Approval" now says clearly what is still missing (vendor, prices) with links
- Production mode (PROCURETRACK_ENV=production) for the live server: test sign-in off,
  HTTPS-only cookies, works behind IIS / nginx / Azure; /health check for monitoring
- Clear message instead of an error page if Microsoft sign-in is misconfigured
- docs/DEPLOYMENT.md: hosting (incl. Cloudflare Tunnel), install, Microsoft 365, backups, upgrades, go-live checklist
- Categories reduced to Electronics, Mechanical, Software, Service (older tickets keep theirs)
